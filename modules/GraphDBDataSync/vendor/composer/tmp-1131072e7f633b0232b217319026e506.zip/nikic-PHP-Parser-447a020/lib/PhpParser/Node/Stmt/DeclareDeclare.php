<?php declare(strict_types=1);

namespace PhpParser\Node\Stmt;

use PhpParser\Node\DeclareItem;

require __DIR__ . '/../DeclareItem.php';

if (false) {
    // For classmap-authoritative support.
    class DeclareDeclare extends DeclareItem {
    }
}
