<?php declare(strict_types=1);

namespace PhpParser\Node\Scalar;

use PhpParser\Node\InterpolatedStringPart;

require __DIR__ . '/../InterpolatedStringPart.php';

if (false) {
    // For classmap-authoritative support.
    class EncapsedStringPart extends InterpolatedStringPart {
    }
}
