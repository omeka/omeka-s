<?php

namespace Laminas\Loader\Exception;

require_once __DIR__ . '/DomainException.php';

class SecurityException extends DomainException
{
}
